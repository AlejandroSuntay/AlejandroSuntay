#include <iostream>
#include <string>

class Point {
public:
    double x, y;
};

void stackVsHeap() {
    std::string stackString("Hello");
    std::string* heapString = new std::string("World");

    std::cout << "Addresses: " << &stackString << " and " << heapString << std::endl;
    std::cout << "Values: " << stackString << " and " << *heapString << std::endl;

    delete heapString;
}

void pointToSameMemory() {
    std::string* heapString = new std::string("Hello Heap");
    std::string* otherPtr = heapString;

    std::cout << "Addresses: " << otherPtr << " and " << heapString << std::endl;
    std::cout << "Values: " << *otherPtr << " and " << *heapString << std::endl;

    delete heapString;
}

void memoryLeak() {
    std::string* heapString = new std::string("Hello Heap");
    std::cout << "Value: " << *heapString << std::endl;
    // dont' delete heapString;
}

void danglingPointer() {
    std::string* heapString = new std::string("Hello Heap");
    std::string* otherPtr = heapString;

    delete heapString;
    heapString = nullptr;

    std::cout << "About to delete from dangling pointer" << std::endl;
    std::cout << "Value: " << *otherPtr << std::endl;
}

/* Your warning settings prevent this from building
std::string* dontReturnAddressOnStack() {
    std::string stackString("Hello");
    return &stackString;
}
*/

std::string* returnHeapAddress() {
    return new std::string("Hello Heap");
}

void heapArray() {
    int* ints = new int[3];
    ints[0] = 1;
    ints[1] = 2;

    std::cout << &ints[0] << std::endl << &ints[1] << std::endl << &ints[2] << std::endl;
    std::cout << "Values: " << ints[0] << " and " << ints[1] << std::endl;

    delete[] ints;
}

Point* createPoint(double x, double y) {
    Point* pt = new Point();
    pt->x = x;
    pt->y = y;
    return pt;
}

int main() {
    //stackVsHeap();
    //pointToSameMemory();
    //memoryLeak();
    //danglingPointer();

    //std::string* s = dontReturnAddressOnStack();
    //std::cout << *s << std::endl;

    /*
    std::string* s = returnHeapAddress();
    std::cout << *s << std::endl;
    // Don't leak memory
    delete s;
    */

    //heapArray();

    Point * pt = createPoint(20, 30);
    std::cout << pt->x << ", " << (*pt).y << std::endl;
    delete pt;
    return 0;
}