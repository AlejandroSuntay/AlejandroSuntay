//
// Created by Scott McMaster on 4/18/21.
//

#include <iostream>
#include "Point.h"

void doSomething(const Point p) {
    std::cout << "Address: " << &p << ": " << p.getX() << ", " << p.getY() << std::endl;
}

int main() {
    Point p1(10, 20);

    // Calls copy constructor because we're creating a new instance.
    Point p2 = p1;
    std::cout << "Address: " << &p2 << ": " << p2.getX() << ", " << p2.getY() << std::endl;

    // Calls copy constructor.
    doSomething(p2);

    // Calls assignment operator because we're assigning to an existing instance.
    Point p3(100, 200);
    p2 = p3;

    return 0;
}