//
// Created by Scott McMaster on 4/18/21.
//

#ifndef LECTURECODE_POINT_H
#define LECTURECODE_POINT_H


class Point
{
private:
    int x, y;

public:
    Point(int x1, int y1);

    // Copy constructor
    Point(const Point &p1);

    // Assignment operator
    Point& operator=(const Point& p1);

    int getX() const;
    int getY() const;
};


#endif //LECTURECODE_POINT_H
