#include <iostream>
#include <stdexcept>
#include <math.h>

double doDivision(double num, double denom) {
    if (denom == 0) {
        throw std::invalid_argument("denom can't be zero");
    }
    return num / denom;
}

double doSquareRoot(double num) {
    if (num < 0) {
        throw std::invalid_argument("can't sqrt a negative number");
    }
    return sqrt(num);
}

double quadraticFirstRoot(double a, double b, double c) {
    return (-b + doSquareRoot(b*b - 4*a*c)) / 2*a;
}

int main() {
    std::cout << "Exception demo" << std::endl;

    // Don't catch
    doDivision(6, 0);
    std::cout << "Didn't handle, this line never gets hit" << std::endl;

    // Catch
    /*
    try {
        doDivision(6, 0);
    } catch (const std::invalid_argument& err) {
        std::cerr << "Oops, caught this: " << err.what() << std::endl;
    }
    std::cout << "Caught it, so we kept going" << std::endl;
    */

    // Propagation
    //quadraticFirstRoot(1, -3, 4);

    return 0;
}