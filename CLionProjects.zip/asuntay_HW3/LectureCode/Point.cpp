//
// Created by Scott McMaster on 4/18/21.
//

#include "Point.h"
#include <iostream>

Point::Point(int x1, int y1) {
    x = x1;
    y = y1;
}

// Copy constructor
Point::Point(const Point& p1) {
    std::cout << "copy ctor" << std::endl;
    x = p1.x;
    y = p1.y;
}

Point& Point::operator=(const Point &p1) {
    std::cout << "assignment op" << std::endl;

    // Check for assignment to self
    if (this != &p1)
    {
        x = p1.x;
        y = p1.y;
    }  // end if

    return *this;
}

int Point::getX() const {
    return x;
}

int Point::getY() const {
    return y;
}