#include <iostream>
#include "String.h"

int main() {
    std::cout << "StringDemo" << std::endl;

    // TODO: Test String methods here

    return 0;
}
