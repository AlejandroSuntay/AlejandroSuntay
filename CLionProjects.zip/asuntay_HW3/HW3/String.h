#ifndef LECTURECODE_STRING_H
#define LECTURECODE_STRING_H

// TODO: Implement
class String {

};


#endif //LECTURECODE_STRING_H
