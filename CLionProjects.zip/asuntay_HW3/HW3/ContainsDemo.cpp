#include <iostream>

int main() {
    std::cout << "ContainsDemo" << std::endl;

    // TODO: Test LinkedList.contains() here

    // TODO: Test LinkedList.containsRecursive() here

    return 0;
}
