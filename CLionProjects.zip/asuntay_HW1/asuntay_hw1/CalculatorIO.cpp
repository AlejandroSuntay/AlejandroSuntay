
#include <iostream>
#include <fstream>
#include <vector>
#include "Calculator.h"
using namespace std;

// TOOO: CalculatorIO implementation goes in this file.
// Reads calculations line by line from input file and writes the results line by line to the output file.
// If an error occurs on any given calculation, the output should include:
//  1. A description of the error.
//  2. An indication of what line number the error occurred on.
//  3. And the method should continue processing the rest of the lines in the file.
//
// Example input file:
// 7 * 8
// 24 / 4
//
// Example output file:
// 56
// 6


void CalculateFile(const string& inputFilePath, const string& outputFilePath) {
    vector <string> v1; //vector we save our string into

    ifstream inputFile; //input file stream
    ofstream outputFile; //output file stream

    //opening the files
    inputFile.open(inputFilePath, ios::in);
    outputFile.open(outputFilePath, ios::out);

    //loop to write file to the string
    while(!inputFile.eof()){
        //use delim to split num1 & num2 and read in as a line
        string str1;
        
    }
}

void CalculateWithString (const string& inputFilePath, const string& outputFilePath){
    double num1; //user inputted number 1
    char op; //user inputted op
    double num2; //user inputted number 2
    string str1;

    ifstream inputFile; //input file stream
    ofstream outputFile; //output file stream

    inputFile.open(inputFilePath, ios::in);
    outputFile.open(outputFilePath, ios::out);

    vector <string> v1; //vector we save our string into
    cout << "Please enter the equation separated by spaces (e.g.1 + 2)";
    cin >> str1;
    while(getline(inputFile, str1, ' ')) {
        v1.push_back(str1);
        num1 = v1[0][0];
        op = v1[0][1];
        num2 = v1[0][2]; //user inputted number 2 pulled from vector1 index 0 pos 2
    }
}
//fix this to enter the entire line as a string
//read in full line "5 + 6"
//split each value by space
//add to vector v1
//format is str" "char" "str (str is just an array of char)
//turn vector[0] to double <--- check book
//if that fails "illegal first num"
//try to turn vector[1]
//for op we need index 0 of v1 eg v1[1][0]
double CalculateInteractive() {
    //create calc obj
    Calculator calc;
    return 0;
    //print to output
}

 