#include "Calculator.h"
#include <iostream>
#
using namespace std;
// TOOO: Calculator implementation goes in this file.

// Adds two numbers and returns the result.
    double Add(const double num1, const double num2){
        return num1 + num2;
    }

    // Subtracts two numbers and returns the result.
    double Subtract(const double num1, const double num2){
        return  num1 - num2;
    }

    // Multiplies two numbers and returns the result.
    double Multiply(const double num1, const double num2){
        return num1 * num2;
    }


    // Divides two numbers and returns the result.
    double Divide(const double num1, const double num2){
        if (num2 != 0)
            return  num1 / num2;

        else
            throw invalid_argument("Cannot divide by 0 -- please make sure num2 != 0: ");
    }

    // Runs the given calculation and returns the result.
    double Calc(const double num1, const double num2, const char op){
        //apply ops to num1/num2
        if(op == '+'){
            return Add(num1,num2);
        }
        else if(op == '-'){
            return Subtract(num1,num2);
        }
        else if(op == '*'){
            return Multiply(num1,num2);
        }
        else if(op == '/'){
            return Divide(num1,num2);
        }
        //error #5 illegal op
        else
            throw invalid_argument("Illegal operator -- please enter +, -, *, or /: ");

}

