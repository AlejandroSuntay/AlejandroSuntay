#ifndef HW1_CALCULATORIO_H
#define HW1_CALCULATORIO_H

#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include "Calculator.h"
using namespace std;


// Command-line and file-based interfaces for the Calculator.
// Throws appropriate exceptions for invalid calculations or file operations.
class CalculatorIO {
public:
    // Reads calculations line by line from input file and writes the results line by line to the output file.
    // If an error occurs on any given calculation, the output should include:
    //  1. A description of the error.
    //  2. An indication of what line number the error occurred on.
    //  3. And the method should continue processing the rest of the lines in the file.
    //
    // Example input file:
    // 7 * 8
    // 24 / 4
    //
    // Example output file:
    // 56
    // 6
    void CalculateFile(const string& inputFilePath, const string& outputFilePath) {
       // vector <string> v1; //vector we save our string into

        string operand;
        ifstream inputFile; //input file stream
        ofstream outputFile; //output file stream
        double firstNum, secondNum, total;
        
        //opening the files
        inputFile.open(inputFilePath, ios::in);
        outputFile.open(outputFilePath, ios::out);

        string str;
        //loop to write file to the string
        while (getline(inputFile, str)) {
            //use delim to split num1 & num2 and read in as a line
            istringstream iss(str);
            iss >> firstNum >> operand >> secondNum;

            if (operand == "+") {
                total = calc.Add(firstNum, secondNum);
         
            }
            else if (operand == "-") {
                total = calc.Subtract(firstNum, secondNum);
            }
            else if (operand == "*") {
                total = calc.Multiply(firstNum, secondNum);
            }
            else if (operand == "/") {
                total = calc.Divide(firstNum, secondNum);
            }
            else perror("invalid operations");

            outputFile << total << "\n";
            //print to output

            /*if (str.size() > 0) v1.push_back(str);*/
           
        }

    }

    //does calculations with string
    void CalculateWithString(const string& inputFilePath, const string& outputFilePath) {
        double num1; //user inputted number 1
        char op; //user inputted op
        double num2; //user inputted number 2
        string str1;

        ifstream inputFile; //input file stream
        ofstream outputFile; //output file stream

        inputFile.open(inputFilePath, ios::in);
        outputFile.open(outputFilePath, ios::out);

        vector <string> v1; //vector we save our string into
        cout << "Please enter the equation separated by spaces (e.g.1 + 2)";
        cin >> str1;
        while (getline(inputFile, str1, ' ')) {
            v1.push_back(str1);
            num1 = v1[0][0];
            op = v1[0][1];
            num2 = v1[0][2]; //user inputted number 2 pulled from vector1 index 0 pos 2
        }
    }
    // Prompts the user for:
    // 1. First number.
    // 2. Operation (+, -, *, /)
    // 3. Second number.
    // In this order, and uses the Calculator to calculate and return the result.
    double CalculateInteractive() {
        //create calc obj
        Calculator calc;
        char operand;
        double firstNum, secondNum;
        cout << "Enter the first number: ";
        cin >> firstNum;
        cout << "Enter the operation: ";
        cin >> operand;
        cout << "Enter the second number: ";
        cin >> secondNum;
        double total;

        if (operand == '+') {
            total = calc.Add(firstNum, secondNum);
        }
        else if (operand == '-') {
            total = calc.Subtract(firstNum, secondNum);
        }
        else if (operand == '*') {
            total = calc.Multiply(firstNum, secondNum);
        }
        else if (operand == '/') {
            total = calc.Divide(firstNum, secondNum);
        }
        else perror("invalid operations");

        cout << "Total = " << total << "\n";
        return total;
        //print to output
    }



private:
    // calculator obj that we can call to perform our maths.
    Calculator calc;
};

#endif //HW1_CALCULATORIO_H
