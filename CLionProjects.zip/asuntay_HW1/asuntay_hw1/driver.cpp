#include <iostream>
#include <string>
#include "Calculator.h"
#include "CalculatorIO.h"

void testCalc(const std::string& desc, double expected, double actual) {
    if (expected == actual) {
        std::cout << "PASS: " << desc << std::endl;
    }
    else {
        std::cerr << "FAIL: " << desc << "; expected: " << expected << ", actual " << actual << std::endl;
    }
}

// Driver program that tests Calculator and CalculatorIO.
// Your code MUST pass these tests.
// But note that we can and will run other tests when grading to ensure that your code meets the requirements.
// driver will catch exceptions
int main() {
    Calculator calc;
    testCalc("basic add", 5, calc.Add(3, 2));
    testCalc("basic sub", 1, calc.Subtract(3, 2));
    testCalc("basic mult", 6, calc.Multiply(3, 2));
    testCalc("basic div", 1.5, calc.Divide(3, 2));

    CalculatorIO io{};
    //std::cout << "Calculate something that calculates to 5" << std::endl;
    //testCalc("basic calc to 5 interactive", 5, io.CalculateInteractive());

    io.CalculateFile("input.txt", "output.txt");
    

    //incl all 6 errors to check here
    //error #1 illegal num1
    std::cout << "Enter a string instead of a number" << std::endl;
    bool caughtException = false;
    try {
        io.CalculateInteractive();
    }
    catch (const std::invalid_argument& err) {
        caughtException = (std::string(err.what()) == "ERROR: num1 invalid");
    }
    if (caughtException) {
        std::cout << "PASS: invalid first number" << std::endl;
    }
    else {
        std::cerr << "FAIL: invalid first number" << std::endl;
    }
    //error #2 illegal second num != null
    std::cout << "Enter a string instead of a number" << std::endl;
    bool caughtException2 = false;
    try {
        io.CalculateInteractive();
    }
    catch (const std::invalid_argument& err) {
        caughtException2 = (std::string(err.what()) == "ERROR: num2 invalid or NULL");
    }
    if (caughtException2) {
        std::cout << "PASS: invalid second number" << std::endl;
    }
    else {
        std::cerr << "FAIL: invalid second number" << std::endl;
    }
    //error #3 invalid format (5 + 6 7) v1.len != 3
    std::cout << "Enter a string instead of a number" << std::endl;
    bool caughtException3 = false;
    try {
        io.CalculateInteractive();
    }
    catch (const std::invalid_argument& err) {
        caughtException3 = (std::string(err.what()) == "ERROR: invalid input");
    }
    if (caughtException3) {
        std::cout << "PASS: invalid input" << std::endl;
    }
    else {
        std::cerr << "FAIL: invalid input" << std::endl;
    }
    //error #4 dividing by 0 (in div when num2 = 0)
    std::cout << "Enter a string instead of a number" << std::endl;
    bool caughtException4 = false;
    try {
        io.CalculateInteractive();
    }
    catch (const std::invalid_argument& err) {
        caughtException4 = (std::string(err.what()) == "ERROR: Cannot divide by 0");
    }
    if (caughtException4) {
        std::cout << "PASS: Cannot divide by 0" << std::endl;
    }
    else {
        std::cerr << "FAIL: Cannot divide by 0" << std::endl;
    }

    //error #5 illegal op (5 *( 4) v1.len != 3
    std::cout << "Enter a string instead of a number" << std::endl;
    bool caughtException5 = false;
    try {
        io.CalculateInteractive();
    }
    catch (const std::invalid_argument& err) {
        caughtException5 = (std::string(err.what()) == "ERROR: Illegal operator");
    }
    if (caughtException5) {
        std::cout << "PASS: invalid operator" << std::endl;
    }
    else {
        std::cerr << "FAIL: invalid operator" << std::endl;
    }
    //error #6 illegal file name
    std::cout << "Enter a string instead of a number" << std::endl;
    bool caughtException6 = false;
    try {
        io.CalculateInteractive();
    }
    catch (const std::invalid_argument& err) {
        caughtException6 = (std::string(err.what()) == "ERROR: Invalid Filename");
    }
    if (caughtException6) {
        std::cout << "PASS: invalid filename" << std::endl;
    }
    else {
        std::cerr << "FAIL: invalid filename" << std::endl;
    }
    //file
    io.CalculateFile("input.txt", "output.txt");

    //return
    return 0;
}
