#include <iostream>
#include <string>
#include <fstream>
#include <algorithm> 
#include <cctype>

bool isPalindrome(std::string word, int left, int right) {
    // if string is one char
    if (left >= right) { return true; }

    // check left letter = right letter
    if (word[left] != word[right]) { return false; }

    return isPalindrome(word, left + 1, right - 1);
}
    //process for string
std::string processString(std::string word) {
    transform(word.begin(), word.end(), word.begin(), tolower);
    word.erase(remove_if(word.begin(), word.end(), isspace), word.end());
    return word;
}

int main() {


    std::ifstream inputFile;
    std::string currentWord, fileName;
    //prompt the user to enter the filename
    std::cout << "Please enter the filename: ";
    //load filename
    std::cin >> fileName;
    //new ln
    std::cout << "\n";
    inputFile.open(fileName, std::ifstream::in);
    //if they enter incorrect fn then prompt user
    if (!inputFile) {
        std::cout << "Unable to open the file. Please enter a valid filename. \n";
        return 0;
    }
    //main logic loop
    while (getline(inputFile, currentWord)) {
        //process string to remove case and space
        std::cout << currentWord;
        currentWord = processString(currentWord);
        if (isPalindrome(currentWord, 0, currentWord.length() - 1)) {
            std::cout << " is a palindrome.\n";
        }
        else std::cout << " is not a palindrome.\n";

    }
    return 0;
}
