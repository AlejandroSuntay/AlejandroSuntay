#include <iostream>
#include <vector>



template <typename T>   //any type
std::vector <T> reversedV (std::vector <T> vec) {

    //return if vector is sorted
    if (vec.size() == 1) {
        return vec;
    }
    else {
        T temp = vec.at(0);
        vec.erase(vec.begin());
        vec = reversedV(vec);
        vec.push_back(temp);

        return vec;
    }
}

int main() {
    // TEST AN ARRAY OF INTS
    std::vector <int> vec{ 1, 5, 6, 7, 10 };
    //TODO
    std::vector<int> temp = reversedV(vec);
    for(int x:temp){
        std::cout << x << " ";
    }
        std::cout << std::endl;


    // TEST AN ARRAY OF STRINGS
    std::vector<std::string> strings { "cat", "dog", "bird", "cow", "frog", "horse" };
    //TODO
    std::vector<std::string> temp1 = reversedV(strings);
    for(std::string x:temp1){
        std::cout << x << " ";
    }

    return 0;
}