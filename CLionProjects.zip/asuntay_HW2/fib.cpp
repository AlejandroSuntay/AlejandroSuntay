#include <iostream>
#include <bits/stdc++.h>

int fibRecursive(int n)
{
    if (n <= 1)
        return n;
    return fibRecursive(n - 1) + fibRecursive(n - 2);
}

int fibIterative(int num) {
    int x = 0, y = 1, z = 0;
    for (int i = 0; i < num; i++) {
        std::cout << x << " ";
        z = x + y;
        x = y;
        y = z;
    }
}

int fibRecursiveBetter(int n, int x = 0, int y = 1)
{
    if (n == 0)
        return x;
    if (n == 1)
        return y;
    return fibRecursiveBetter(n - 1, y, x + y);
}

int main ()
{
    int n = 45; // 45 recursions
    //print loop
    for (int i = 0; i < n; i++){
        std::cout << "Recursive" << std::endl;
        std::cout << fibRecursive(i) << std::endl;
    }

    for (int a = 0; a < n; a++){
        std::cout << "Iterative" << std::endl;
        std::cout << fibIterative(a) << std::endl;
    }

    for (int j = 0; j < n; j++){
        std::cout << "Recursive Better" << std::endl;
        std::cout << fibRecursiveBetter(j) << std::endl;
    }

    return 0;
}