#include <iostream>
#include <bits/stdc++.h>
// Prints total weight in pounds of all the coins used by all the possible combinations
// of 1, 5, 10, 25, 50 cent coins to make $1


// here is the
// value of the coin
   const int total = 1;
// all the different coins
    float change[] = {0.01,0.05,0.25,0.10,0.50};
// weights of the different coins
    float weights[] = {2.5,5.0,2.268,5.670,11.340};


    int main(){
        // no of coins for the particular array
        long long dp[(total * 100) + 1];
        // weight of the coins for the particular value array
        float weight[(total * 100) + 1] = {0};
        // init w/ -1
        memset(dp, -1, sizeof(dp));
        // # of coins when = 0
        dp[0] = 0;
        // all coins
        for(int i = 0; i < 5; i++){
            // find sum
            for(int j = 1; j <= total; j++){
                // taking in 100sop
                int k = change[i] * 100;
                // value check
                if(j >= k){
                    // check for change
                    if(dp[j - k]!= -1){
                        if(dp[j] == -1) dp[j] = dp[j - k] +1;
                        else dp[j] += dp[j - k] +1;
                        // prev weight + new coin weight = new weight
                        weight[j] += weight[j - k] + weights[i];
                    }
                }
            }
        }
        // print for amount of coins + weight
        std::cout<< "probably the answer: " << dp[total]<<" "<<weight[total]<<std::endl;
    }
